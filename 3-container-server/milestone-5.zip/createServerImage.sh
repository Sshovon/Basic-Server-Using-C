#!/bin/sh

#creating apache-web server image naming it server-image
docker build -t server-image .


