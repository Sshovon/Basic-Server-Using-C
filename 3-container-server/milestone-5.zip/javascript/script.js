const loginFormDiv = document.getElementById('login-div');
const logoutBtn = document.getElementById('logout-btn');
const allPoemTable=document.getElementById('show-all-poem')
const allOwnPoemTable=document.getElementById('show-all-own-poem')
const poemIDTable= document.getElementById('show-poem-by-id');
const restrictedDiv=document.getElementById('restricted-routes');
//console.log(poemIDTable);
//console.log(allPoemTable)
//let sessionID=extractCookie("sessionID");

onLoadFunc =  () => {

    //console.log(document.cookie)
    let valid;
    fetch('http://localhost:8180/valid', {
        method: 'GET',
        credentials: 'include',
        headers: {
            Cookie: document.cookie
        }
    }).then((response) => {
        return response.text()
    }).then(res => {
        valid = extractXMLData(res, '<message>', '</message>');
        if (valid === 'valid') {
            loginFormDiv.style.display = "none"
            logoutBtn.style.display = "block"
            loadRestrictedFunctions();
        }else {
            loginFormDiv.style.display = "block"
            logoutBtn.style.display = "none"
        }
        //clearTableData();
    })


}

logoutFunc = () => {
    console.log(document.cookie);
    fetch('http://localhost:8180/logout', {
        method: 'GET',
        credentials: 'include',
        headers: {
            Cookie: document.cookie
        }
    }).then(() => {
        document.cookie = "sessionID="
        location.reload()
    })
}

loadRestrictedFunctions = () => {
    restrictedDiv.style.display="block";
}

loginAPI = (email, password) => {
    let data = `<credential><email>${email}</email><password>${password}</password></credential>`
    fetch('http://localhost:8180/login', {
        method: 'POST',
        body: data,
        credentials: 'include'
    }).then(response => {
        return response.text()
    }).then(res => {
        let msg = extractXMLData(res, '<message>', '</message>');
        if (msg === "Successful") {
            location.reload();
        } else {
            alert("Wrong Credentials");
            location.reload()
        }
    })
}

getLoginData = () => {
    email = document.forms["login-data"]["email"].value;
    password = document.forms["login-data"]["password"].value;
    document.forms["login-data"].reset();
    if ((email != "") && (password != "")) {
        loginAPI(email, password);
    }
}

getAllPoem = ()=>{
    clearTableData();
    allPoemTable.innerHTML="<tr><th>poemID</th><th>Poem</th><th>email</th></tr>";
    let rows = allPoemTable.getElementsByTagName("tr")
    let totalRowCount=0;
    for (let i = 0; i < rows.length; i++) {
            totalRowCount++;
    }
    //console.log(totalRowCount);
    
    fetch("http://localhost:8180/poems",{
        method: 'GET',
    }).then(response=>{
        return response.text();
    }).then(res=>{
        allPoemTable.style.display="block"
        //console.log(res);
        res=res.slice(res.indexOf("<Poem>"),res.lastIndexOf("</Poem>")+"</Poem>".length);
        //console.log(res);
        const poems=res.split(/\r?\n/);
        //console.log(poems)

        for(let i=0;i<poems.length;i++){
            //console.log(poems[i])
            let poem=extractXMLData(poems[i],'<Poem>','</Poem>');
            //console.log(poem);
            let row=allPoemTable.insertRow(i+1);
            let cell1=row.insertCell(0);
            let cell2=row.insertCell(1);
            let cell3=row.insertCell(2);
            cell1.innerHTML=`${extractXMLData(poem,"<poemID>","</poemID>")}`
            cell2.innerHTML=`${extractXMLData(poem,"<poem>","</poem>")}`
            cell3.innerHTML=`${extractXMLData(poem,"<email>","</email>")}`
        
        }
        allPoemTable.innerHTML+="<br>";
    
	
    })
}

getPoemByID = ()=>{
    clearTableData();
    poemIDTable.innerHTML="<tr><th>poemID</th><th>Poem</th><th>email</th></tr>";
    let rows = poemIDTable.getElementsByTagName("tr")
    let totalRowCount=0;
    for (let i = 0; i < rows.length; i++) {
            totalRowCount++;
    }
    //console.log(totalRowCount);
    id = document.forms["search-poem-id"]["poemID"].value;
    document.forms["search-poem-id"].reset();
    
    fetch(`http://localhost:8180/poem/${id}`,{
        method: 'GET',
    }).then(response=>{
        return response.text();
    }).then(res=>{
        poemIDTable.style.display="block"
        let poem=extractXMLData(res,'<Poem>','</Poem>');
        let row=poemIDTable.insertRow(totalRowCount);
        let cell1=row.insertCell(0);
        let cell2=row.insertCell(1);
        let cell3=row.insertCell(2);
        cell1.innerHTML=`${extractXMLData(poem,"<poemID>","</poemID>")}`
        cell2.innerHTML=`${extractXMLData(poem,"<poem>","</poem>")}`
        cell3.innerHTML=`${extractXMLData(poem,"<email>","</email>")}`
        poemIDTable.innerHTML+="<br>";
    

    })
    
}

getAllOwnPoem = ()=>{
    clearTableData();
    allOwnPoemTable.innerHTML="<tr><th>poemID</th><th>Poem</th><th>email</th></tr>";
    let rows = allOwnPoemTable.getElementsByTagName("tr")
    let totalRowCount=0;
    for (let i = 0; i < rows.length; i++) {
            totalRowCount++;
    }
    //console.log(totalRowCount);
    
    fetch("http://localhost:8180/poems/own",{
        method: 'GET',
        credentials: 'include',
        headers: {
            Cookie: document.cookie
        }
    }).then(response=>{
        return response.text();
    }).then(res=>{
        allOwnPoemTable.style.display="block"
        //console.log(res);
        res=res.slice(res.indexOf("<Poem>"),res.lastIndexOf("</Poem>")+"</Poem>".length);
        //console.log(res);
        const poems=res.split(/\r?\n/);
        //console.log(poems)

        for(let i=0;i<poems.length;i++){
            //console.log(poems[i])
            let poem=extractXMLData(poems[i],'<Poem>','</Poem>');
            //console.log(poem);
            let row=allOwnPoemTable.insertRow(i+1);
            let cell1=row.insertCell(0);
            let cell2=row.insertCell(1);
            let cell3=row.insertCell(2);
            cell1.innerHTML=`${extractXMLData(poem,"<poemID>","</poemID>")}`
            cell2.innerHTML=`${extractXMLData(poem,"<poem>","</poem>")}`
            cell3.innerHTML=`${extractXMLData(poem,"<email>","</email>")}`
        
        }
        allOwnPoemTable.innerHTML+="<br>";
    })
}

addPoem = ()=>{
    clearTableData()
    title = document.forms["add-poem"]["title"].value;
    document.forms["add-poem"].reset();
    //console.log(title);
    let data = `<poem><title>${title}</title></poem>`
    fetch('http://localhost:8180/poem', {
        method: 'POST',
        body: data,
        credentials: 'include',
        headers: {
            Cookie: document.cookie
        }
    }).then( ()=> {
        alert("Poem added successfully!!");
    })
}

editPoem = ()=>{
    clearTableData()
    id = document.forms["edit-poem"]["id"].value;
    title = document.forms["edit-poem"]["title"].value;
    document.forms["edit-poem"].reset();
    //console.log(title);
    //console.log(id);

    let data = `<poem><title>${title}</title></poem>`
    fetch(`http://localhost:8180/poem/${id}`, {
        method: 'PUT',
        body: data,
        credentials: 'include',
        headers: {
            Cookie: document.cookie
        }
    }).then( (response)=> {
        return response.text();
    }).then(res=>{
        let msg=extractXMLData(res,'<message>','</message>');
        if(msg==="Poem updated")
            alert("Poem edited successfully!!");
        else
            alert("You can't edit this poem!!");
    

    })
    
}

deletePoem = ()=>{
    clearTableData()
    id = document.forms["delete-poem"]["id"].value;
    document.forms["delete-poem"].reset();
    //console.log(id)
    fetch(`http://localhost:8180/poem/${id}`, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
            Cookie: document.cookie
        }
    }).then( (response)=> {
        return response.text();
    }).then(res=>{
        let msg=extractXMLData(res,'<message>','</message>');
        if(msg==="Poem deleted")
            alert("Poem deleted!!!");
        else
            alert("You can't delete this poem!!");
    

    })
}

deleteAllPoem = ()=>{
    clearTableData()
    fetch(`http://localhost:8180/deleteall`, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
            Cookie: document.cookie
        }
    }).then( ()=> {
        alert("All of poems are deleted!!!")
    })
}

clearTableData = ()=>{
    poemIDTable.style.display="none";
    allPoemTable.style.display="none";
    allOwnPoemTable.style.display="none";
    
}

reloadPage =()=>{
    location.reload()
}

extractXMLData = (str, parameter1, parameter2) => {
    let start = str.indexOf(parameter1) + parameter1.length
    let end = str.indexOf(parameter2)
    return str.slice(start, end);

}

extractCookie = (cName) => {
    const name = cName + "=";
    const cDecoded = decodeURIComponent(document.cookie)
    const cArr = cDecoded.split('; ');
    let res;
    cArr.forEach(val => {
        if (val.indexOf(name) === 0) res = val.substring(name.length);
    })
    return res
}