const cacheName = 'v1.1';

self.addEventListener("install", (ev) => {
    console.log("in install")
    ev.waitUntil(
        caches
            .open(cacheName)
            .then(cache => {
                console.log("caching file")
                cache.addAll([
                    './',
                    './ui.html',
                    './script.js',
                    './style.css',
                ]
                )
            }).then(() => {
                self.skipWaiting();
            })
    )

})

self.addEventListener("activate", (ev) => {
    console.log("in activate")
    //removing unwanted caches
    ev.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames.map(cache => {
                        if (cache != cacheName) {
                            console.log("Clearing old cache");
                            return caches.delete(cache);
                        }

                    })
                )
            })
    )
})

self.addEventListener("fetch", (e) => {
    console.log("IN FETCH : SERVICE WORKER")
        e.respondWith(async()=>{
            try{
                const response = await fetch(e.request);
                if(response.ok){
                    const cache=await caches.open(cacheName);
                    await cache.put(e.request,response.clone());
                    return response;
        
                }
            }catch(error){
                const cachedResponse = await caches.match(e.request);
                return cachedResponse
            }
        })
        

})



// fromNetwork(e.request,1000).catch(function(){
//     return fromCache(e.request);
// })


function fromNetwork(request,timeout){
    return new Promise(function(fullfill,reject){
        let timeoutID= setTimeout(reject,timeout);
        fetch(request).then(function(response){
            clearTimeout(timeoutID);

            const clonedRes=response.clone();
            caches.open(cacheName).then(cache=>{
                cache.put(request,clonedRes)
            })
            fullfill(response);
        },reject)
    })
}


function fromCache(request){
    return caches.open(cacheName).then(function(cache){
        return cache.match(request).then(function(matching){
            return matching || Promise.reject('no-match')
        })
    })
}