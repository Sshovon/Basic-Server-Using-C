#!/bin/sh


rm -rf ./container
