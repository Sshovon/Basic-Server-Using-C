const cacheName = 'v2.0';

self.addEventListener("install", (ev) => {
    console.log("in install")
    ev.waitUntil(
        caches
            .open(cacheName)
            .then(cache => {
                console.log("caching file")
                cache.addAll([
                    './',
                    './ui.html',
                    './script.js',
                    './style.css',
                    './gruppe11-xml.xml',
                    './gruppe11-xml.css',
                    './index.html',
                    './style-main.css',
                ]
                )
            }).then(() => {
                self.skipWaiting();
            })
    )

})

self.addEventListener("activate", (ev) => {
    console.log("in activate")
    //removing unwanted caches
    ev.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames.map(cache => {
                        if (cache != cacheName) {
                            console.log("Clearing old cache");
                            return caches.delete(cache);
                        }

                    })
                )
            })
    )
})

self.addEventListener("fetch", (event) => {
    console.log('Fetch event for ', event.request.url, ' ', event.request.method);
    event.respondWith(caches.open(cacheName).then((cache) => {
        // Go to the network first
        return fetch(event.request).then((fetchedResponse) => {
            if(event.request.method=="GET"){
                cache.put(event.request.url, fetchedResponse.clone());
            }
            return fetchedResponse;
        }).catch(() => {
            // If the network is unavailable, get
            return cache.match(event.request.url);
        });
    }));



})



// fromNetwork(e.request,1000).catch(function(){
//     return fromCache(e.request);
// })


// function fromNetwork(request,timeout){
//     return new Promise(function(fullfill,reject){
//         let timeoutID= setTimeout(reject,timeout);
//         fetch(request).then(function(response){
//             clearTimeout(timeoutID);

//             const clonedRes=response.clone();
//             caches.open(cacheName).then(cache=>{
//                 cache.put(request,clonedRes)
//             })
//             fullfill(response);
//         },reject)
//     })
// }


// function fromCache(request){
//     return caches.open(cacheName).then(function(cache){
//         return cache.match(request).then(function(matching){
//             return matching || Promise.reject('no-match')
//         })
//     })
// }




// e.respondWith(async()=>{
//     try{
//         const response = await fetch(e.request);
//         if(response.ok){
//             if(e.request.method=="GET" && e.request.url != "http://localhost:8180/logout"){
//                 const cache=await caches.open(cacheName);
//                 await cache.put(e.request,response.clone());
//             }
//             return response;


//         }
//     }catch(error){
//         if(e.request.method=='GET'){
//             const cachedResponse = await caches.match(e.request);
//             return cachedResponse
//         }
//     }
// })

// event.respondWith(
//     fetch(event.request)
//         .then(response => {
//             if(event.request.method=="GET"){
//                 return caches.open(cacheName)
//                 .then(cache => {
//                     cache.put(event.request.url, response.clone());
//                     return response;
//                 })
//             }
//         })
//         .catch(() => {
//             if(event.request.method=="GET"){
//                 caches.open(cacheName)
//                 .then(cache => {
//                     cache.match(event.request)
//                         .then(response => {
//                             return response;

//                         })
//                 })
//             }else{
//                 caches.open(cacheName)
//                 .then(cache=>{
//                     cache.match("404.html")
//                     .then(response=>{
//                         return response;
//                     })
//                 })
//             }
//         })
// )

